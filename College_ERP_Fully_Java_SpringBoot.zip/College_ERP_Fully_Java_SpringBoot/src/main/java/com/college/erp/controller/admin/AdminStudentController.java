package com.college.erp.controller.admin;

import com.college.erp.model.Student;
import com.college.erp.repository.StudentRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class AdminStudentController {

    private final StudentRepository repo;

    public AdminStudentController(StudentRepository repo) {
        this.repo = repo;
    }

    // Open Add Student Page
    @GetMapping("/admin/add-student")
    public String addStudentPage(){
        return "admin/add-student";
    }

    // Save Student
    @PostMapping("/admin/save-student")
    public String saveStudent(Student student){
        repo.save(student);
        return "redirect:/admin/students";
    }

    // View Students List
    @GetMapping("/admin/students")
    public String viewStudents(Model model){
        model.addAttribute("list", repo.findAll());
        return "admin/students";
    }

    // Delete Student
    @GetMapping("/admin/delete-student/{id}")
    public String deleteStudent(@PathVariable Long id){
        repo.deleteById(id);
        return "redirect:/admin/students";
    }

    // Open Edit Student Page
    @GetMapping("/admin/edit-student/{id}")
    public String editStudent(@PathVariable Long id, Model model){
        model.addAttribute("student", repo.findById(id).get());
        return "admin/edit-student";
    }

    // Update Student
    @PostMapping("/admin/update-student")
    public String updateStudent(Student student){
        repo.save(student);
        return "redirect:/admin/students";
    }

}
